using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RefractionIndexData : MonoBehaviour
{
    public int refractionModeID = 1;//id of refracIndex(wavelength)

    public float GetRefractionIndex(int refrectionModeID, float wavelength)
    {
        switch (refrectionModeID)
        {
            case 1:return (2.0f-0.001f*wavelength);break;

            default:return (1);break;
        }
    }


}
