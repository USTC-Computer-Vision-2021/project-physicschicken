using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BulletReflect : MonoBehaviour
{
    private void OnCollisionEnter(Collision collision)
    {
        var tag = collision.collider.tag;
        //Debug.Log("impact");
        if (tag == "reflect")
        {
            Debug.Log("ReflectionImpact!!");
            //Vector3 planeNormal = other.transform.forward;  //plane mirror only

            //gather needed vector
            Vector3 planeNormal = collision.contacts[0].normal;
            BulletFly bulletFly = this.GetComponent<BulletFly>();
            Vector3 incident = bulletFly.direction;

            //reflection calculation, should make it a function in a headfile in the future, model is as below
            Vector3 projection = Vector3.Dot(planeNormal, incident) * planeNormal;
            Vector3 reflection = incident - 2 * projection;

            //output
            bulletFly.direction = reflection;

        }
    }
    // \    /|\   /|
    //  \    |   /
    //   \ | |  /
    //   __| | /
    //-----------
    //the result of the formula above is not sensitive to the relative direction of incident and normal
}
