using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BulletRefraction : MonoBehaviour
{
    //if OnCollisionExit detects a total internal reflection occurs, give the probe an exemption of a refraction check
    
    private int totalInternalReflection = 0;
    private ContactPoint lastContactPoint;//Store the last contact point since OnCollisionExit is fired at the next frame of actual exit and dont store contact point data
    private void OnCollisionEnter(Collision collision)
    {
        var tag = collision.collider.tag;
        //Debug.Log("impact");
        if (tag == "refraction" && totalInternalReflection == 0)
        {
            Debug.Log("RefractionImpact!!");
            
            //gather needed data
            Vector3 planeNormal = collision.contacts[0].normal;
            BulletFly bulletFly = this.GetComponent<BulletFly>();
            Vector3 incident = bulletFly.direction;
            RefractionIndexData newRefractionProperty = collision.gameObject.GetComponent<RefractionIndexData>();
            float newRefractionIndex = newRefractionProperty.GetRefractionIndex(newRefractionProperty.refractionModeID, bulletFly.wavelength);

            //Refraction calculation
            bulletFly.direction = RefractCalculation(incident, planeNormal, 1, newRefractionIndex);
            bulletFly.currentRefractionIndex = newRefractionIndex;

            //log
            Debug.Log("Refraction:InVelocity" + incident + "Angle:" + Vector3.Angle(planeNormal, incident));
            Debug.Log("Refraction:InVelocity2" + bulletFly.direction + "Angle" + Vector3.Angle(planeNormal, bulletFly.direction));

        }

        totalInternalReflection = 0;
    }

    private void OnCollisionStay(Collision collision)
    {
        foreach(ContactPoint i in collision.contacts)
        {
            lastContactPoint = i;
        }
    }

    private void OnCollisionExit(Collision collision)
    {
        var tag = collision.collider.tag;
        //Debug.Log("impact");
        if (tag == "refraction")
        {
            Debug.Log("RefractionImpactOut!!");

            //gather needed data
            Vector3 planeNormal = lastContactPoint.normal;
            BulletFly bulletFly = this.GetComponent<BulletFly>();
            Vector3 incident = bulletFly.direction;
            RefractionIndexData newRefractionProperty = collision.gameObject.GetComponent<RefractionIndexData>();
            float newRefractionIndex = newRefractionProperty.GetRefractionIndex(newRefractionProperty.refractionModeID, bulletFly.wavelength);

            //Refraction calculation
            bulletFly.direction = RefractCalculation(incident, planeNormal, newRefractionIndex, 1);
            bulletFly.currentRefractionIndex = 1;

            //
            Debug.Log("Refraction:OutVelocity" + incident + "Angle:" + Vector3.Angle(planeNormal,incident));
            Debug.Log("Refraction:OutVelocity2" + bulletFly.direction + "Angle" + Vector3.Angle(planeNormal,bulletFly.direction));

        }
    }

    //Refraction Calculation
    // \       / \
    //  \ L     |
    //   \      |  N                    n1
    //    \ |   |
    //   ___|a1 |
    //---------------------------------------------------
    //          |\
    //          |a2
    //          |  \
    //          |   \ |    T            n2
    //          |   __|
    //T = L*e - (cos(a1)*e-cosa2)N e=n1/n2
    //the result is sensitive to the relative direction of LN
    //

    private Vector3 RefractCalculation(Vector3 incident,Vector3 normal,float n1, float n2)
    {
        float e = n1 / n2;
        Debug.Log(e);
        float cosa1 = Vector3.Dot(incident, normal);
        float cosa2sq = 1 - (1-cosa1*cosa1)*e*e;
        //
        if (cosa1 < 0)
        {
            cosa1 = -1 * cosa1;
            normal = -1 * normal;
        }

        if (cosa2sq > 0)     //Normal Refraction
        {
            return (incident*e-(cosa1*e-Mathf.Sqrt(cosa2sq))*normal);
        }
        else                 //Total Internal Reflection
        {
            totalInternalReflection = 1;
            Debug.Log("TIR!!!");
            //reflection calculation, should make it a function in a headfile in the future
            Vector3 projection = Vector3.Dot(normal, incident) * normal;
            Vector3 reflection = incident - 2 * projection;

            return (reflection);
        }
        
    }


}
