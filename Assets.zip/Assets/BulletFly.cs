using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BulletFly : MonoBehaviour
{
    //BulletFly Script is about the flying direction and light properties
    //light properties include the refraction index of current material and wavelength, polarization, phase of the photon(bullet)
    
    //light properties
    public float moveSpeed = 5;
    public Vector3 direction;
    public float wavelength = 700;  //visible:380-780
    private float alpha = 0.8f;
    public float airRefractionIndex = 1;
    public float currentRefractionIndex = 1;

    private void Start()
    {
        TrailRenderer tr = gameObject.GetComponent<TrailRenderer>();
        Vector3 rgb = WavelengthToRGB(wavelength);
        Color color;
        color.r = rgb.x;color.g = rgb.y;color.b = rgb.z;color.a = alpha;
        tr.startColor = color;
        color.a = 0;
        tr.endColor = color;
    }

    // Update is called once per frame
    void Update()
    {
        //fly
        this.transform.Translate(direction*Time.deltaTime*moveSpeed/currentRefractionIndex, Space.World);

    }

    private Vector3 WavelengthToRGB(float wavelength)
    {
        float r, g, b;
        if ((wavelength >= 380) && (wavelength < 440))
        {
            r = -1 * (wavelength - 440) / 60;
            g = 0;
            b = 1;
        }
        else if ((wavelength >= 440) && (wavelength < 490))
        {
            r = 0;
            g = (wavelength - 440) / 50;
            b = 1;
        }
        else if ((wavelength >= 490) && (wavelength < 510))
        {
            r = 0;
            g = 1;
            b = -1*(wavelength-510)/20;
        }
        else if ((wavelength >= 510) && (wavelength < 580))
        {
            r = (wavelength-510)/70;
            g = 1;
            b = 0;
        }
        else if ((wavelength >= 580) && (wavelength < 645))
        {
            r = 1;
            g = -1*(wavelength - 645) / 65;
            b = 0;
        }
        else if ((wavelength >= 645) && (wavelength < 781))
        {
            r = 1;
            g = 0;
            b = 0;
        }
        else
        {
            r = 0;
            g = 0;
            b = 0;
            alpha = 0;
        }

        Vector3 rgb;
        rgb.x = r;rgb.y = g;rgb.z = b;

        return rgb;
    }
    
    

}
