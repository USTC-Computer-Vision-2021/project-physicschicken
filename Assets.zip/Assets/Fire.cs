using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.EventSystems;

public class Fire : MonoBehaviour
{
    public GameObject bullet;

    public float wavelength = 700;
    //public float moveSpeed = 5;
    public void FireProcess()
    {
        //Debug.Log("buttonClicked");

        GameObject[] laserTurrets;

        laserTurrets = GameObject.FindGameObjectsWithTag("laser");

        for(int i=0;i<laserTurrets.Length; i++)
        {
            //Debug.Log(laserTurrets[i].name);

            Vector3 pos = laserTurrets[i].transform.position;
            Vector3 face = -1*laserTurrets[i].transform.up;

            //Debug.Log(face);

            GameObject bulletShot = GameObject.Instantiate(bullet, pos, Quaternion.Euler(0,0,0));
            //Debug.Log(bulletShot.transform.forward);
            BulletFly bulletFly = bulletShot.GetComponent<BulletFly>();
            bulletFly.direction = face;
            bulletFly.wavelength = wavelength;
            //bulletFly.moveSpeed = moveSpeed;

        }

    }
}
