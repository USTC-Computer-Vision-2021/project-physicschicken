using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BulletLifeTime : MonoBehaviour
{
    public int maxLifeFrame = 2000;
    private int currentFrame = 0; 

    // Update is called once per frame
    void Update()
    {
        currentFrame += 1;
        if (currentFrame > maxLifeFrame)
        {
            GameObject.DestroyImmediate(gameObject);
        }
    }
}
